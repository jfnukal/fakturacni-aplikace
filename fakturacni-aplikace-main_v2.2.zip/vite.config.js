import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  
  // Předoptimalizace závislostí (TOP LEVEL)
  optimizeDeps: {
    include: ['firebase/app', 'firebase/firestore', 'firebase/storage', 'firebase/auth'],
    force: true
  },
  
  // ESBuild optimalizace (TOP LEVEL)
  esbuild: {
    target: 'esnext',
    minifyIdentifiers: true,
    minifySyntax: true
  },
  
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          firebase: ['firebase/app', 'firebase/firestore', 'firebase/storage', 'firebase/auth'],
          react: ['react', 'react-dom'],
          ui: ['lucide-react', 'react-hot-toast'],
        }
      }
    },
    target: 'esnext',
    minify: 'terser',
    sourcemap: false,
    chunkSizeWarningLimit: 1000,
  },
  
  // Dev server optimalizace
  server: {
    hmr: {
      overlay: false
    }
  }
});