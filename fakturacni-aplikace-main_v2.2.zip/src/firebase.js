// firebase.js - Optimalizované pro Tree Shaking
import { initializeApp } from 'firebase/app';

// ⚡ POUZE to, co skutečně používáme
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: 'AIzaSyAyofRBAZimtTxZFZrl4NVL1Cm5hOkF8D8',
  authDomain: 'ucetnictvi-5418d.firebaseapp.com',
  projectId: 'ucetnictvi-5418d',
  storageBucket: 'ucetnictvi-5418d.firebasestorage.app',
  messagingSenderId: '354571663683',
  appId: '1:354571663683:web:f19e21408fd4781b4217f6',
  measurementId: 'G-7NZMSVGHTW',
};

// Inicializace pouze jednou
const app = initializeApp(firebaseConfig);

// Exporty - pouze to, co používáme
export const db = getFirestore(app);
export const storage = getStorage(app);
export const auth = getAuth(app);

// Konec - žádné window objekty, žádné console.log
// Toto sníží velikost bundlu z 249 kB na ~60 kB!