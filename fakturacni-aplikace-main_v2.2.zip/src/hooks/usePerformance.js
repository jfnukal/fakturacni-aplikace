import { useEffect, useRef, useCallback } from 'react';

export const useDebounce = (callback, delay) => {
  const timeoutRef = useRef(null);
  
  return useCallback((...args) => {
    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => callback(...args), delay);
  }, [callback, delay]);
};

export const useThrottle = (callback, limit) => {
  const inThrottle = useRef(false);
  
  return useCallback((...args) => {
    if (!inThrottle.current) {
      callback(...args);
      inThrottle.current = true;
      setTimeout(() => inThrottle.current = false, limit);
    }
  }, [callback, limit]);
};

export const useIntersectionObserver = (callback, options = {}) => {
  const ref = useRef(null);
  
  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    
    const observer = new IntersectionObserver(callback, options);
    observer.observe(element);
    
    return () => observer.disconnect();
  }, [callback, options]);
  
  return ref;
};

// Virtual scrolling hook pro dlouhé seznamy
export const useVirtualScrolling = (items, itemHeight = 50, containerHeight = 400) => {
  const scrollTop = useRef(0);
  const visibleStart = Math.floor(scrollTop.current / itemHeight);
  const visibleEnd = Math.min(
    visibleStart + Math.ceil(containerHeight / itemHeight) + 1,
    items.length
  );
  
  const visibleItems = items.slice(visibleStart, visibleEnd).map((item, index) => ({
    ...item,
    index: visibleStart + index
  }));
  
  const totalHeight = items.length * itemHeight;
  const offsetY = visibleStart * itemHeight;
  
  const handleScroll = useCallback((e) => {
    scrollTop.current = e.target.scrollTop;
  }, []);
  
  return {
    visibleItems,
    totalHeight,
    offsetY,
    handleScroll
  };
};

// Performance monitoring
export const usePerformanceMonitor = (componentName) => {
  const startTime = useRef(Date.now());
  
  useEffect(() => {
    const renderTime = Date.now() - startTime.current;
    if (renderTime > 100) { // Pokud render trvá déle než 100ms
      console.warn(`${componentName} slow render: ${renderTime}ms`);
    }
  });
  
  useEffect(() => {
    startTime.current = Date.now();
  });
};

// Memory leak prevention
export const useCleanup = (cleanupFn) => {
  useEffect(() => {
    return cleanupFn;
  }, [cleanupFn]);
};

export default {
  useDebounce,
  useThrottle,
  useIntersectionObserver,
  useVirtualScrolling,
  usePerformanceMonitor,
  useCleanup
};