import React, { useState, useEffect, useRef } from 'react';
import { db, storage } from '../firebase';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import {
  Upload,
  Save,
  AlertCircle,
  Settings,
  Database,
  RotateCcw,
  Bell,
  Clock,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { IMaskInput } from 'react-imask';
import { LazyImportTool } from '../components/LazyComponents';
import { Building } from 'lucide-react';
import toast from 'react-hot-toast';

// Import zálohovacích komponent
import BackupComponent from '../components/BackupComponent';
import RestoreComponent from '../components/RestoreComponent';
import BackupSettingsComponent from '../components/BackupSettingsComponent';

// --- Funkce pro validaci českého čísla účtu ---
const validateCzechBankAccount = (accountString) => {
  if (!accountString || accountString === '/') return true; // Povolíme prázdné pole
  if (!/^((\d{1,6})-)?(\d{2,10})\/(\d{4})$/.test(accountString)) {
    return false; // Nesplňuje základní formát
  }
  const parts = accountString.replace('-', '/').split('/');
  const [prefix, number] =
    parts.length === 3 ? [parts[0], parts[1]] : ['', parts[0]];

  const weights = [6, 3, 7, 9, 10, 5, 8, 4, 2, 1];

  const validatePart = (numStr) => {
    if (!numStr || numStr.length === 0) return true;
    let sum = 0;
    for (let i = 0; i < numStr.length; i++) {
      sum +=
        parseInt(numStr[i], 10) * weights[weights.length - numStr.length + i];
    }
    return sum % 11 === 0;
  };

  if (!validatePart(prefix)) return false;
  if (!validatePart(number)) return false;

  return true;
};
// ----------------------------------------------------

const SettingsPage = ({
  currentUser,
  savedCustomers,
  products,
  deliveryNotes,
  appSettings,
  setAppSettings,
}) => {
  const { t } = useTranslation();

  // Stav pro taby
  const [activeTab, setActiveTab] = useState('general');

  const [supplier, setSupplier] = useState({
    name: '',
    address: '',
    zip: '',
    city: '',
    ico: '',
    dic: '',
    bankAccount: '',
    paymentMethod: 'Převodem',
    logoUrl: '',
    financniUrad: '',
  });
  const [vatSettings, setVatSettings] = useState({
    enabled: false,
    defaultRate: 21,
  });
  const [logoPreview, setLogoPreview] = useState('');
  const fileInputRef = useRef(null);
  const [bankAccountError, setBankAccountError] = useState('');

  const fetchSupplierFromAres = async (ico) => {
    if (!ico || !/^\d{8}$/.test(ico)) {
      alert(t('customers_page.alert.invalid_ico'));
      return;
    }
    const proxiedUrl = `/.netlify/functions/ares?ico=${ico}`;
    try {
      const response = await fetch(proxiedUrl);
      if (!response.ok) {
        throw new Error(t('customers_page.alert.ares_error'));
      }
      const data = await response.json();

      console.log(
        '[SettingsPage.jsx] PŘIJATÁ ZPRACOVANÁ ODPOVĚĎ ZE SERVERU:',
        data
      );

      if (!data || !data.obchodniJmeno) {
        alert(t('customers_page.alert.company_not_found'));
        return;
      }

      const aresData = {
        name: data.obchodniJmeno,
        address: data.address,
        zip: data.zip,
        city: data.city,
        ico: data.ico,
        dic: data.dic || '',
        registeringAuthority:
          data.zivnostenskyUrad?.nazev || supplier.registeringAuthority || '',
        financniUrad: data.financniUrad?.nazev || '',
      };

      setSupplier((prev) => ({ ...prev, ...aresData }));
      toast.success('Údaje o firmě byly úspěšně načteny z ARESu!');
    } catch (error) {
      alert(error.message || t('customers_page.alert.ares_fetch_failed'));
    }
  };

  const [prefix, setPrefix] = useState('');
  const [number, setNumber] = useState('');
  const [code, setCode] = useState('');

  useEffect(() => {
    const fullAccount = supplier.bankAccount || '';
    const [mainPart = '', codePart = ''] = fullAccount.split('/');
    const [prefixPart = '', numberPart = ''] = mainPart.includes('-')
      ? mainPart.split('-')
      : ['', mainPart];
    setPrefix(prefixPart);
    setNumber(numberPart);
    setCode(codePart);
  }, [supplier.bankAccount]);

  useEffect(() => {
    const currentFullAccount = supplier.bankAccount || '';
    let newAccountString = '';

    if (prefix || number || code) {
      newAccountString = prefix
        ? `${prefix}-${number}/${code}`
        : `${number}/${code}`;
    }

    if (newAccountString !== currentFullAccount) {
      setSupplier((prev) => ({ ...prev, bankAccount: newAccountString }));
    }
  }, [prefix, number, code]);

  useEffect(() => {
    if (!currentUser) return;
    const settingsDocRef = doc(db, 'settings', currentUser.uid);
    const unsubscribe = onSnapshot(settingsDocRef, (doc) => {
      if (doc.exists()) {
        const data = doc.data();
        if (data.supplierDetails) setSupplier(data.supplierDetails);
        if (data.vatDetails) setVatSettings(data.vatDetails);
      }
    });
    return () => unsubscribe();
  }, [currentUser]);

  const saveSettings = async (skipToast = false) => {  // PŘIDÁN parametr
    if (
      supplier.bankAccount &&
      !validateCzechBankAccount(supplier.bankAccount)
    ) {
      setBankAccountError('Zadané číslo účtu není platné.');
      return;
    }
  
    if (!currentUser) return;
    try {
      await setDoc(doc(db, 'settings', currentUser.uid), {
        supplierDetails: supplier,
        vatDetails: vatSettings,
        appSettings: appSettings,
        userId: currentUser.uid,
      });
      
      if (!skipToast) {  // POUZE pokud není skipToast true
        toast.success('Nastavení uloženo!');
      }
      setBankAccountError('');
    } catch (error) {
      console.error('Chyba při ukládání nastavení: ', error);
      toast.error('Chyba při ukládání nastavení.');
    }
  };

  const handleBankAccountBlur = () => {
    if (
      supplier.bankAccount &&
      !validateCzechBankAccount(supplier.bankAccount)
    ) {
      setBankAccountError('Zadané číslo účtu není platné.');
    } else {
      setBankAccountError('');
    }
  };

  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      alert('Obrázek je příliš velký. Maximum jsou 2MB.');
      return;
    }
    const localUrl = URL.createObjectURL(file);
    setLogoPreview(localUrl);
    const storageRef = ref(
      storage,
      `logos/${currentUser.uid}/${Date.now()}_${file.name}`
    );
    try {
      await uploadBytes(storageRef, file);
      const fileUrl = await getDownloadURL(storageRef);
      setSupplier({ ...supplier, logoUrl: fileUrl });
      alert('Logo úspěšně nahráno. Nezapomeňte uložit nastavení.');
    } catch (error) {
      console.error('Chyba při nahrávání loga: ', error);
      alert('Chyba při nahrávání loga.');
      setLogoPreview('');
    }
  };

  // Funkce pro toggle docházky
  const toggleAttendance = async () => {
    const newSettings = {
      ...appSettings,
      attendanceEnabled: !appSettings.attendanceEnabled
    };
    
    try {
      await setDoc(doc(db, 'settings', currentUser.uid), {
        supplierDetails: supplier,
        vatSettings: vatSettings,
        appSettings: newSettings,
        userId: currentUser.uid,
      }, { merge: true });
      
      setAppSettings(newSettings);
      toast.success(newSettings.attendanceEnabled ? 'Docházkový systém byl zapnut' : 'Docházkový systém byl vypnut');
    } catch (error) {
      console.error('Chyba při ukládání nastavení:', error);
      toast.error('Chyba při ukládání nastavení');
    }
  };

  // Definice tabů
  const tabs = [
    {
      id: 'general',
      label: t('backup_system.tabs.general_settings'),
      icon: Settings,
    },
    {
      id: 'backup',
      label: t('backup_system.tabs.create_backup'),
      icon: Database,
    },
    {
      id: 'restore',
      label: t('backup_system.tabs.restore_backup'),
      icon: Upload,
    },
    {
      id: 'backup-settings',
      label: t('backup_system.tabs.backup_settings'),
      icon: Bell,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-xl sm:text-2xl font-bold">{t('settingsTitle')}</h2>
      </div>

      {/* Taby */}
      <div className="bg-white rounded-lg border">
        <div className="border-b border-gray-200">
          <nav className="flex overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 border-b-2 font-medium text-sm whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {/* Nastavení funkcí aplikace */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
              <Settings size={20} className="text-blue-600" />
              Funkce aplikace
            </h3>
            
            <div className="space-y-4">
              {/* Toggle pro docházku */}
              <div className="flex items-center justify-between p-4 bg-white rounded-lg border">
                <div className="flex items-center gap-3">
                  <Clock size={20} className="text-gray-600" />
                  <div>
                    <h4 className="font-medium text-gray-900">Docházkový systém</h4>
                    <p className="text-sm text-gray-600">
                      Evidence pracovní doby zaměstnanců podle zákoníku práce
                    </p>
                  </div>
                </div>
                <button
                  onClick={toggleAttendance}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                    appSettings?.attendanceEnabled ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      appSettings?.attendanceEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
          {activeTab === 'general' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">
                  {t('supplierDetails')}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 gap-x-4 md:gap-x-6 gap-y-4">
                  <div className="col-span-1 sm:col-span-1 md:col-span-3">
                    <label
                      htmlFor="company-name"
                      className="block text-sm font-medium text-gray-700"
                    >
                      {t('placeholder_companyName')}
                    </label>
                    <input
                      type="text"
                      id="company-name"
                      placeholder="Firma s.r.o."
                      value={supplier.name}
                      onChange={(e) =>
                        setSupplier({ ...supplier, name: e.target.value })
                      }
                      className="mt-1 w-full p-2 border rounded"
                    />
                  </div>
                  <div className="col-span-1 sm:col-span-1 md:col-span-3">
                    <label
                      htmlFor="address"
                      className="block text-sm font-medium text-gray-700"
                    >
                      {t('placeholder_address')}
                    </label>
                    <input
                      type="text"
                      id="address"
                      placeholder="Hlavní 123"
                      value={supplier.address}
                      onChange={(e) =>
                        setSupplier({ ...supplier, address: e.target.value })
                      }
                      className="mt-1 w-full p-2 border rounded"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label
                      htmlFor="zip"
                      className="block text-sm font-medium text-gray-700"
                    >
                      {t('placeholder_zip')}
                    </label>
                    <input
                      type="text"
                      id="zip"
                      placeholder="700 30"
                      value={supplier.zip || ''}
                      onChange={(e) =>
                        setSupplier({ ...supplier, zip: e.target.value })
                      }
                      className="mt-1 w-full p-2 border rounded"
                    />
                  </div>
                  <div className="md:col-span-4">
                    <label
                      htmlFor="city"
                      className="block text-sm font-medium text-gray-700"
                    >
                      {t('placeholder_city')}
                    </label>
                    <input
                      type="text"
                      id="city"
                      placeholder="Ostrava"
                      value={supplier.city}
                      onChange={(e) =>
                        setSupplier({ ...supplier, city: e.target.value })
                      }
                      className="mt-1 w-full p-2 border rounded"
                    />
                  </div>
                  <div className="col-span-1 sm:col-span-1 md:col-span-3">
                    <label
                      htmlFor="ico"
                      className="block text-sm font-medium text-gray-700"
                    >
                      {t('placeholder_ico')}
                    </label>
                    <div className="flex items-center gap-2 mt-1">
                      <input
                        type="text"
                        id="ico"
                        placeholder="12345678"
                        value={supplier.ico}
                        onChange={(e) =>
                          setSupplier({ ...supplier, ico: e.target.value })
                        }
                        className="w-full p-2 border rounded"
                      />
                      <button
                        type="button"
                        onClick={() => fetchSupplierFromAres(supplier.ico)}
                        className="p-2 bg-gray-200 rounded hover:bg-gray-300"
                        title="Načíst údaje z ARESu"
                      >
                        <Building size={20} />
                      </button>
                    </div>
                  </div>
                  <div className="col-span-1 sm:col-span-1 md:col-span-3">
                    <label
                      htmlFor="dic"
                      className="block text-sm font-medium text-gray-700"
                    >
                      {t('placeholder_dic')}{' '}
                      <span className="text-gray-400">(nepovinné)</span>
                    </label>
                    <input
                      type="text"
                      id="dic"
                      placeholder="CZ12345678"
                      value={supplier.dic}
                      onChange={(e) =>
                        setSupplier({ ...supplier, dic: e.target.value })
                      }
                      className="mt-1 w-full p-2 border rounded"
                    />
                  </div>

                  <div className="md:col-span-6">
                    <label
                      htmlFor="registering-authority"
                      className="block text-sm font-medium text-gray-700"
                    >
                      Živnostenský úřad (doplňte, pokud ARES nenašel)
                    </label>
                    <input
                      type="text"
                      id="registering-authority"
                      placeholder="např. Městský úřad Bruntál"
                      value={supplier.registeringAuthority || ''}
                      onChange={(e) =>
                        setSupplier({
                          ...supplier,
                          registeringAuthority: e.target.value,
                        })
                      }
                      className="mt-1 w-full p-2 border rounded"
                    />
                  </div>

                  <div className="col-span-1 sm:col-span-1 md:col-span-3">
                    <label
                      htmlFor="bank-prefix"
                      className="block text-sm font-medium text-gray-700"
                    >
                      {t('bankAccount')}
                    </label>
                    <div
                      onBlur={handleBankAccountBlur}
                      className={`flex items-center mt-1 border rounded w-full transition-colors duration-200 bg-white focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500 ${
                        bankAccountError ? 'border-red-500' : 'border-gray-300'
                      }`}
                    >
                      <IMaskInput
                        mask={'000000'}
                        value={prefix}
                        onAccept={(value) => setPrefix(value)}
                        placeholder="Prefix"
                        className="p-2 border-0 focus:ring-0 bg-transparent text-right w-20"
                      />
                      <span className="px-1 text-gray-400">-</span>
                      <IMaskInput
                        mask={'0000000000'}
                        value={number}
                        onAccept={(value) => setNumber(value)}
                        placeholder="Číslo účtu"
                        className="p-2 border-0 focus:ring-0 bg-transparent flex-grow"
                      />
                      <span className="px-1 text-gray-400">/</span>
                      <IMaskInput
                        mask={'0000'}
                        value={code}
                        onAccept={(value) => setCode(value)}
                        placeholder="Kód"
                        className="p-2 border-0 focus:ring-0 bg-transparent w-16"
                      />
                    </div>
                    {bankAccountError && (
                      <div className="text-red-600 text-sm mt-1 flex items-center gap-1">
                        <AlertCircle size={14} /> {bankAccountError}
                      </div>
                    )}
                  </div>

                  <div className="md:col-span-3 flex items-end pb-1">
                    <div className="space-y-3">
                      <label className="flex items-center gap-3 w-full">
                        <input
                          type="checkbox"
                          checked={vatSettings.enabled}
                          onChange={(e) =>
                            setVatSettings({
                              ...vatSettings,
                              enabled: e.target.checked,
                            })
                          }
                          className="w-4 h-4"
                        />
                        <span>{t('vatPayer')}</span>
                      </label>

                      {vatSettings.enabled && (
                        <div className="pl-7 space-y-2">
                          <label
                            htmlFor="default-vat"
                            className="block text-sm font-medium text-gray-700"
                          >
                            Výchozí sazba DPH pro nové položky
                          </label>
                          <select
                            id="default-vat"
                            value={vatSettings.defaultRate || 21}
                            onChange={(e) =>
                              setVatSettings({
                                ...vatSettings,
                                defaultRate: parseInt(e.target.value, 10),
                              })
                            }
                            className="mt-1 w-full max-w-xs p-2 border rounded"
                          >
                            <option value="21">21% (základní)</option>
                            <option value="12">12% (snížená)</option>
                            <option value="0">0% (bez DPH)</option>
                          </select>
                          <div className="text-xs text-gray-500">
                            Tato sazba se automaticky předvyplní u nových
                            položek na faktuře.
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-4">{t('companyLogo')}</h3>
                <div className="flex items-center gap-4">
                  {(logoPreview || supplier.logoUrl) && (
                    <div className="w-20 h-20 border rounded flex items-center justify-center bg-gray-50 overflow-hidden">
                      <img
                        src={logoPreview || supplier.logoUrl}
                        alt="Logo firmy"
                        className="w-full h-full object-contain"
                      />
                    </div>
                  )}
                  <div className="flex flex-col gap-2">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      onChange={handleLogoUpload}
                      className="hidden"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                    >
                      <Upload size={16} /> {t('uploadLogo')}
                    </button>
                    {(supplier.logoUrl || logoPreview) && (
                      <button
                        onClick={() => {
                          setLogoPreview('');
                          setSupplier({ ...supplier, logoUrl: '' });
                        }}
                        className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
                      >
                        {t('remove')}
                      </button>
                    )}
                    <div className="text-xs text-gray-500">
                      {t('maxFileSize')}
                    </div>
                  </div>
                </div>
              </div>

              {/* Import dodacích listů */}
              <div className="mt-8">
                <LazyImportTool
                  currentUser={currentUser}
                  savedCustomers={savedCustomers || []}
                  products={products || []}
                  onImportComplete={(count) => {
                    alert(`Úspěšně importováno ${count} dodacích listů!`);
                  }}
                />
              </div>

              <div className="mt-4">
                <button
                  onClick={saveSettings}
                  className="flex items-center gap-2 px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700"
                >
                  <Save size={16} /> {t('saveSettings')}
                </button>
              </div>
            </div>
          )}

          {activeTab === 'backup' && (
            <BackupComponent currentUser={currentUser} />
          )}

          {activeTab === 'restore' && (
            <RestoreComponent currentUser={currentUser} />
          )}

          {activeTab === 'backup-settings' && (
            <BackupSettingsComponent currentUser={currentUser} />
          )}
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
