import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { db } from '../firebase';
import { useAuth } from '../context/AuthContext';
import {
  collection,
  addDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  deleteDoc,
  doc,
} from 'firebase/firestore';
import {
  Plus,
  Calendar,
  Clock,
  Users,
  FileDown,
  Printer,
  Trash2,
  BarChart3,
  Filter,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import toast from 'react-hot-toast';
import {
  MobileCard,
  DesktopOnly,
  MobileOnly,
} from '../components/ResponsiveTable';

const AttendancePage = ({ creationRequest, setCreationRequest }) => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [filteredRecords, setFilteredRecords] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  // Formulářové stavy - UPRAVENO
  const getInitialFormData = () => ({
    employeeName: '',
    workDate: new Date().toISOString().split('T')[0],
    startTime: '08:00',
    endTime: '16:30',
    breakDuration: '0.5', // v hodinách, 0.5 = 30 minut
    workType: 'Běžná práce',
  });

  const [formData, setFormData] = useState(getInitialFormData());

  // Filtrační stavy
  const [filters, setFilters] = useState({
    employee: '',
    period: 'all',
    workType: '',
  });

  // Načtení dat z Firebase
  useEffect(() => {
    if (!currentUser) return;

    const q = query(
      collection(db, 'attendance'),
      where('userId', '==', currentUser.uid),
      orderBy('created', 'desc')
    );

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const records = [];
      querySnapshot.forEach((doc) => {
        records.push({ id: doc.id, ...doc.data() });
      });
      setAttendanceRecords(records);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Reagovat na creationRequest
  useEffect(() => {
    if (creationRequest === 'attendance') {
      setShowAddForm(true);
      setCreationRequest(null);
    }
  }, [creationRequest, setCreationRequest]);

  // Filtrování záznamů
  useEffect(() => {
    let filtered = [...attendanceRecords];

    if (filters.employee) {
      filtered = filtered.filter(
        (record) => record.employeeName === filters.employee
      );
    }

    if (filters.workType) {
      filtered = filtered.filter(
        (record) => record.workType === filters.workType
      );
    }

    const today = new Date();
    switch (filters.period) {
      case 'today':
        filtered = filtered.filter((record) => {
          const recordDate = new Date(record.workDate);
          return recordDate.toDateString() === today.toDateString();
        });
        break;
      case 'week':
        const weekStart = new Date(today);
        weekStart.setDate(
          today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1)
        ); // Začátek týdne v pondělí
        weekStart.setHours(0, 0, 0, 0);
        filtered = filtered.filter(
          (record) => new Date(record.workDate) >= weekStart
        );
        break;
      case 'month':
        filtered = filtered.filter((record) => {
          const recordDate = new Date(record.workDate);
          return (
            recordDate.getMonth() === today.getMonth() &&
            recordDate.getFullYear() === today.getFullYear()
          );
        });
        break;
      default:
        break;
    }

    setFilteredRecords(filtered);
  }, [attendanceRecords, filters]);

  // Přidání nového záznamu - ZCELA PŘEPRACOVÁNO
  const handleSubmit = useCallback(
    async (e) => {
      e.preventDefault();

      if (
        !formData.employeeName.trim() ||
        !formData.workDate ||
        !formData.startTime ||
        !formData.endTime
      ) {
        toast.error('Prosím vyplňte jméno, datum a časy práce.');
        return;
      }

      const start = new Date(`1970-01-01T${formData.startTime}`);
      const end = new Date(`1970-01-01T${formData.endTime}`);

      if (end <= start) {
        toast.error('Konec pracovní doby musí být po jejím začátku.');
        return;
      }

      const breakHours = parseFloat(formData.breakDuration) || 0;
      if (breakHours < 0) {
        toast.error('Přestávka nemůže být záporná.');
        return;
      }

      const diffMilliseconds = end - start;
      const grossHours = diffMilliseconds / (1000 * 60 * 60);
      const hoursWorked = grossHours - breakHours;

      if (hoursWorked <= 0) {
        toast.error(
          'Počet odpracovaných hodin po odečtení přestávky musí být kladný.'
        );
        return;
      }

      // Kontrola minimálního odpočinku
      const restCheck = checkRestPeriod(
        formData.employeeName.trim(),
        formData.workDate,
        formData.startTime
      );
      if (!restCheck.isValid) {
        const proceed = window.confirm(
          `${restCheck.message}\n\nChcete přesto pokračovat?`
        );
        if (!proceed) return;
      }

      // Kontrola maximální pracovní doby
      const workTimeWarnings = checkWorkingTimeLimit(
        formData.employeeName.trim(),
        formData.workDate,
        hoursWorked
      );
      if (workTimeWarnings.length > 0) {
        const warningMessage = workTimeWarnings.join('\n');
        const proceed = window.confirm(
          `${warningMessage}\n\nChcete přesto pokračovat?`
        );
        if (!proceed) return;
      }

      try {
        await addDoc(collection(db, 'attendance'), {
          employeeName: formData.employeeName.trim(),
          workDate: formData.workDate,
          startTime: formData.startTime,
          endTime: formData.endTime,
          breakDuration: breakHours,
          hoursWorked: parseFloat(hoursWorked.toFixed(2)), // Uložit vypočítanou hodnotu
          workType: formData.workType,
          userId: currentUser.uid,
          created: new Date().toISOString(),
        });

        toast.success('Záznam byl úspěšně přidán');
        setFormData(getInitialFormData());
        setShowAddForm(false);
      } catch (error) {
        console.error('Chyba při přidávání záznamu:', error);
        toast.error('Chyba při přidávání záznamu');
      }
    },
    [formData, currentUser]
  );

  // Smazání záznamu
  const handleDelete = useCallback(async (id) => {
    if (window.confirm('Opravdu chcete smazat tento záznam?')) {
      try {
        await deleteDoc(doc(db, 'attendance', id));
        toast.success('Záznam byl smazán');
      } catch (error) {
        console.error('Chyba při mazání:', error);
        toast.error('Chyba při mazání záznamu');
      }
    }
  }, []);

  // Export do CSV - UPRAVENO
  const exportToCSV = useCallback(() => {
    if (filteredRecords.length === 0) {
      toast.error('Nejsou k dispozici žádné záznamy pro export');
      return;
    }

    const header =
      'Zaměstnanec,Datum,Začátek,Konec,Přestávka (h),Celkem hodin,Typ práce,Přidáno\n';
    const csv =
      header +
      filteredRecords
        .map((record) => {
          const formattedDate = new Date(record.workDate).toLocaleDateString(
            'cs-CZ'
          );
          const createdDate = new Date(record.created).toLocaleString('cs-CZ');
          return `"${record.employeeName}","${formattedDate}","${record.startTime}","${record.endTime}","${record.breakDuration}","${record.hoursWorked}","${record.workType}","${createdDate}"`;
        })
        .join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute(
      'download',
      `evidence_pracovni_doby_${new Date().toISOString().split('T')[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, [filteredRecords]);

  // Tisk - UPRAVENO
  const handlePrint = useCallback(() => {
    const printWindow = window.open('', '_blank');
    let title = 'Evidence pracovní doby - Výkaz';
    if (filters.employee) title += ` - ${filters.employee}`;
    const periodNames = {
      today: 'Dnes',
      week: 'Tento týden',
      month: 'Tento měsíc',
      all: 'Všechna období',
    };
    title += ` - ${periodNames[filters.period] || 'Všechna období'}`;

    let tableRows = '';
    filteredRecords.forEach((record) => {
      const formattedDate = new Date(record.workDate).toLocaleDateString(
        'cs-CZ'
      );
      tableRows += `
        <tr>
          <td>${record.employeeName}</td>
          <td>${formattedDate}</td>
          <td style="text-align: center">${record.startTime}</td>
          <td style="text-align: center">${record.endTime}</td>
          <td style="text-align: center">${record.breakDuration} h</td>
          <td style="text-align: center; font-weight: bold;">${record.hoursWorked} h</td>
          <td>${record.workType}</td>
        </tr>
      `;
    });

    const totalHours = filteredRecords.reduce(
      (sum, record) => sum + record.hoursWorked,
      0
    );

    printWindow.document.write(`
      <!DOCTYPE html><html><head><title>${title}</title><style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h1 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #f8f9fa; font-weight: bold; }
        .summary { background: #e8f4fd; padding: 15px; margin-top: 20px; border-radius: 5px; }
        .print-date { text-align: right; color: #666; font-size: 12px; margin-top: 20px; }
      </style></head><body>
        <h1>${title}</h1><table><thead><tr>
          <th>Zaměstnanec</th><th>Datum</th>
          <th style="text-align: center">Začátek</th><th style="text-align: center">Konec</th>
          <th style="text-align: center">Přestávka</th><th style="text-align: center">Celkem hodin</th>
          <th>Typ práce</th>
        </tr></thead><tbody>${tableRows}</tbody></table>
        <div class="summary"><strong>Celkem odpracovaných hodin: ${totalHours.toFixed(
          2
        )} h</strong><br>Počet záznamů: ${filteredRecords.length}</div>
        <div class="print-date">Vytisknuto: ${new Date().toLocaleString(
          'cs-CZ'
        )}<br>Systém evidence pracovní doby</div>
      </body></html>
    `);

    printWindow.document.close();
    printWindow.print();
  }, [filteredRecords, filters]);

  // Ostatní funkce (getStats, uniqueEmployees, atd.) zůstávají beze změny
  const stats = useMemo(() => {
    const totalHours = filteredRecords.reduce(
      (sum, record) => sum + record.hoursWorked,
      0
    );
    const uniqueDays = new Set(filteredRecords.map((r) => r.workDate)).size;
    const avgHours = uniqueDays > 0 ? totalHours / uniqueDays : 0;
    const overtimeHours = filteredRecords
      .filter((r) => r.workType === 'Přesčas')
      .reduce((sum, record) => sum + record.hoursWorked, 0);
    return { totalHours, uniqueDays, avgHours, overtimeHours };
  }, [filteredRecords]);

  const uniqueEmployees = useMemo(
    () => [...new Set(attendanceRecords.map((r) => r.employeeName))].sort(),
    [attendanceRecords]
  );

  const uniqueWorkTypes = useMemo(
    () => [...new Set(attendanceRecords.map((r) => r.workType))].sort(),
    [attendanceRecords]
  );

  const handleFilterChange = useCallback((filterType, value) => {
    setFilters((prev) => ({ ...prev, [filterType]: value }));
  }, []);

  // Optimalizovaná funkce pro změny ve formuláři
  const handleFormChange = useCallback((field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  }, []);

  // Kontrola minimálního odpočinku mezi směnami (11 hodin)
  const checkRestPeriod = useCallback(
    (employeeName, newDate, newStartTime) => {
      const lastRecord = attendanceRecords
        .filter((record) => record.employeeName === employeeName)
        .find((record) => {
          const recordDate = new Date(record.workDate);
          const newWorkDate = new Date(newDate);
          const dayDiff =
            Math.abs(newWorkDate - recordDate) / (1000 * 60 * 60 * 24);
          return dayDiff <= 1; // Kontrola posledních 24 hodin
        });

      if (lastRecord) {
        const lastEndTime = new Date(
          `${lastRecord.workDate}T${lastRecord.endTime}`
        );
        const newStartDateTime = new Date(`${newDate}T${newStartTime}`);
        const restHours = (newStartDateTime - lastEndTime) / (1000 * 60 * 60);

        if (restHours < 11) {
          return {
            isValid: false,
            message: `Varování: Mezi směnami je pouze ${restHours.toFixed(
              1
            )} hodin odpočinku. Zákon vyžaduje minimálně 11 hodin.`,
          };
        }
      }

      return { isValid: true };
    },
    [attendanceRecords]
  );

  // Kontrola maximální denní (12h) a týdenní (48h) pracovní doby
  const checkWorkingTimeLimit = useCallback(
    (employeeName, newDate, newHours) => {
      const warnings = [];

      // Kontrola denní doby (max 12 hodin včetně přesčasů)
      if (newHours > 12) {
        warnings.push(
          `Denní pracovní doba ${newHours.toFixed(
            1
          )}h překračuje doporučených 12 hodin.`
        );
      }

      // Kontrola týdenní doby
      const startOfWeek = new Date(newDate);
      startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay() + 1); // Pondělí
      startOfWeek.setHours(0, 0, 0, 0);

      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 6); // Neděle
      endOfWeek.setHours(23, 59, 59, 999);

      const weeklyHours = attendanceRecords
        .filter((record) => {
          const recordDate = new Date(record.workDate);
          return (
            record.employeeName === employeeName &&
            recordDate >= startOfWeek &&
            recordDate <= endOfWeek
          );
        })
        .reduce((sum, record) => sum + record.hoursWorked, 0);

      const totalWeeklyHours = weeklyHours + newHours;
      if (totalWeeklyHours > 48) {
        warnings.push(
          `Týdenní pracovní doba ${totalWeeklyHours.toFixed(
            1
          )}h překračuje zákonných 48 hodin.`
        );
      }

      return warnings;
    },
    [attendanceRecords]
  );

  if (loading) {
    return <div className="flex justify-center py-8">Načítání záznamů...</div>;
  }

  return (
    <div className="space-y-6 mobile-safe-area">
      {/* Header - OPRAVENO */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
            <Clock className="text-blue-600" />
            {t('attendance.title')}
          </h2>
          <p className="text-gray-600 text-sm mt-1">
            {t('attendance.subtitle')}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Hlavní tlačítko přidat */}
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus size={16} />
            {t('attendance.add_record')}
          </button>
          
          {/* Tlačítko filtry - pouze na mobilu */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="sm:hidden flex items-center justify-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Filter size={16} />
            {t('attendance.filters.title')}
          </button>

          {/* Export tlačítka - skryté na mobilu pokud není data */}
          {filteredRecords.length > 0 && (
            <div className="flex gap-2">
              <button
                onClick={exportToCSV}
                className="flex items-center justify-center gap-1 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
              >
                <FileDown size={14} />
                <span className="hidden sm:inline">CSV</span>
              </button>
              <button
                onClick={handlePrint}
                className="flex items-center justify-center gap-1 px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm"
              >
                <Printer size={14} />
                <span className="hidden sm:inline">
                  {t('attendance.print')}
                </span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Statistiky - OPRAVENO */}
      {filteredRecords.length > 0 && (
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg p-6 text-white">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <BarChart3 size={20} />
            {t('attendance.stats.title')}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-white/20 rounded-lg p-4">
              <div className="text-2xl font-bold">
                {stats.totalHours.toFixed(1)}
              </div>
              <div className="text-sm opacity-90">
                {t('attendance.stats.total_hours')}
              </div>
            </div>
            <div className="bg-white/20 rounded-lg p-4">
              <div className="text-2xl font-bold">{stats.uniqueDays}</div>
              <div className="text-sm opacity-90">
                {t('attendance.stats.work_days')}
              </div>
            </div>
            <div className="bg-white/20 rounded-lg p-4">
              <div className="text-2xl font-bold">
                {stats.avgHours.toFixed(1)}
              </div>
              <div className="text-sm opacity-90">
                {t('attendance.stats.avg_hours')}
              </div>
            </div>
            <div className="bg-white/20 rounded-lg p-4">
              <div className="text-2xl font-bold">
                {stats.overtimeHours.toFixed(1)}
              </div>
              <div className="text-sm opacity-90">
                {t('attendance.stats.overtime')}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filtry - OPRAVENO */}
      <div className={`bg-white rounded-lg border p-4 ${showFilters ? 'block' : 'hidden sm:block'}`}>
        <div className="flex items-center gap-2 mb-4">
          <Filter size={16} className="text-gray-500" />
          <h3 className="font-semibold">{t('attendance.filters.title')}</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('attendance.filters.employee')}
            </label>
            <select
              value={filters.employee}
              onChange={(e) => handleFilterChange('employee', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">{t('attendance.filters.all_employees')}</option>
              {uniqueEmployees.map((employee) => (
                <option key={employee} value={employee}>
                  {employee}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('attendance.filters.period')}
            </label>
            <select
              value={filters.period}
              onChange={(e) => handleFilterChange('period', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">{t('attendance.filters.all_time')}</option>
              <option value="today">{t('attendance.filters.today')}</option>
              <option value="week">{t('attendance.filters.this_week')}</option>
              <option value="month">
                {t('attendance.filters.this_month')}
              </option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('attendance.filters.work_type')}
            </label>
            <select
              value={filters.workType}
              onChange={(e) => handleFilterChange('workType', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">{t('attendance.filters.all_types')}</option>
              {uniqueWorkTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={() =>
                setFilters({ employee: '', period: 'all', workType: '' })
              }
              className="w-full px-3 py-2 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
            >
              {t('attendance.filters.clear_filters')}
            </button>
          </div>
        </div>
      </div>

      {/* Formulář pro přidání - OPRAVENO */}
      {showAddForm && (
        <div className="bg-white rounded-lg border p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">
              {t('attendance.form.title')}
            </h3>
            <button
              onClick={() => setShowAddForm(false)}
              className="text-gray-500 hover:text-gray-700"
            >
              ×
            </button>
          </div>
          <form
            onSubmit={handleSubmit}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3"
          >
            <div className="sm:col-span-2 lg:col-span-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('attendance.form.employee_name')} *
              </label>
              <input
                type="text"
                value={formData.employeeName}
                onChange={(e) =>
                  handleFormChange('employeeName', e.target.value)
                }
                className="w-full p-2 border rounded-lg"
                placeholder="Jan Novák"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('attendance.form.work_date')} *
              </label>
              <input
                type="date"
                value={formData.workDate}
                onChange={(e) => handleFormChange('workDate', e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('attendance.form.start_time')} *
              </label>
              <input
                type="time"
                value={formData.startTime}
                onChange={(e) => handleFormChange('startTime', e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('attendance.form.end_time')} *
              </label>
              <input
                type="time"
                value={formData.endTime}
                onChange={(e) => handleFormChange('endTime', e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('attendance.form.break_duration')} (h) *
              </label>
              <input
                type="number"
                step="0.25"
                min="0"
                value={formData.breakDuration}
                onChange={(e) =>
                  handleFormChange('breakDuration', e.target.value)
                }
                className="w-full p-2 border rounded-lg"
                placeholder="0.5"
                required
              />
            </div>
            <div className="sm:col-span-2 lg:col-span-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Typ práce *
              </label>
              <select
                value={formData.workType}
                onChange={(e) => handleFormChange('workType', e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              >
                <option value="Běžná práce">
                  {t('attendance.work_types.regular')}
                </option>
                <option value="Přesčas">
                  {t('attendance.work_types.overtime')}
                </option>
                <option value="Noční směna">
                  {t('attendance.work_types.night_shift')}
                </option>
                <option value="Víkend/svátek">
                  {t('attendance.work_types.weekend_holiday')}
                </option>
              </select>
            </div>
            <div className="sm:col-span-2 lg:col-span-2 flex flex-col sm:flex-row items-stretch sm:items-end gap-2">
              <button
                type="submit"
                className="flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus size={16} />
                {t('attendance.form.add_record')}
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
              >
                {t('common.cancel')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tabulka záznamů - MOBILNÍ OPTIMALIZACE */}
      <div className="bg-white rounded-lg border overflow-hidden">
        {/* Desktop tabulka */}
        <DesktopOnly>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('attendance.table.employee')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('attendance.table.date')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('attendance.table.work_time')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('attendance.table.total_hours')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('attendance.table.work_type')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('attendance.filters.actions')}
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredRecords.length === 0 ? (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-6 py-12 text-center text-gray-500"
                    >
                      <Clock size={48} className="mx-auto mb-4 text-gray-300" />
                      {t('attendance.no_records')}
                    </td>
                  </tr>
                ) : (
                  filteredRecords.map((record) => (
                    <tr key={record.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Users size={16} className="text-gray-400 mr-2" />
                          <span className="font-medium text-gray-900">
                            {record.employeeName}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <div className="flex items-center">
                          <Calendar size={16} className="text-gray-400 mr-2" />
                          {new Date(record.workDate).toLocaleDateString(
                            'cs-CZ'
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {record.startTime} - {record.endTime}{' '}
                        <span className="text-xs">
                          (pauza: {record.breakDuration}h)
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                          {record.hoursWorked.toFixed(2)} h
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            record.workType === 'Přesčas'
                              ? 'bg-orange-100 text-orange-800'
                              : record.workType === 'Noční směna'
                              ? 'bg-purple-100 text-purple-800'
                              : record.workType === 'Víkend/svátek'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {record.workType}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => handleDelete(record.id)}
                          className="text-red-600 hover:text-red-900 flex items-center gap-1"
                        >
                          <Trash2 size={16} />
                          {t('common.delete')}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </DesktopOnly>

        {/* Mobile karty */}
        <MobileOnly>
          {filteredRecords.length === 0 ? (
            <div className="px-6 py-12 text-center text-gray-500">
              <Clock size={48} className="mx-auto mb-4 text-gray-300" />
              <p>{t('attendance.no_records')}</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredRecords.map((record) => (
                <MobileCard
                  key={record.id}
                  className="mobile-card mobile-spacing"
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2">
                      <Users size={16} className="text-gray-400" />
                      <span className="font-medium text-gray-900">
                        {record.employeeName}
                      </span>
                    </div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                      {record.hoursWorked.toFixed(2)} h
                    </span>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar size={14} className="text-gray-400" />
                      <span>
                        {new Date(record.workDate).toLocaleDateString('cs-CZ')}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <Clock size={14} className="text-gray-400" />
                      <span>
                        {record.startTime} - {record.endTime}
                      </span>
                      <span className="text-xs text-gray-500">
                        (pauza: {record.breakDuration}h)
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span
                        className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          record.workType === 'Přesčas'
                            ? 'bg-orange-100 text-orange-800'
                            : record.workType === 'Noční směna'
                            ? 'bg-purple-100 text-purple-800'
                            : record.workType === 'Víkend/svátek'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {record.workType}
                      </span>

                      <button
                        onClick={() => handleDelete(record.id)}
                        className="text-red-600 hover:text-red-900 flex items-center gap-1 px-2 py-1"
                      >
                        <Trash2 size={14} />
                        {t('common.delete')}
                      </button>
                    </div>
                  </div>
                </MobileCard>
              ))}
            </div>
          )}
        </MobileOnly>
      </div>

      {/* Zákonné informace */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <svg
              className="h-5 w-5 text-green-400"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                clipRule="evenodd"
              />
            </svg>
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-green-800">
              {t('attendance.legal.title')}
            </h3>
            <div className="mt-2 text-sm text-green-700">
              <p>{t('attendance.legal.description')}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AttendancePage;
