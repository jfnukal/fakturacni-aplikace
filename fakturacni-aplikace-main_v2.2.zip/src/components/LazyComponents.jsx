import React, { lazy, Suspense } from 'react';

// Lazy loading pro velké komponenty
export const LazyBackupSettingsComponent = lazy(() => import('./BackupSettingsComponent'));
export const LazyDeliveryNotesImportTool = lazy(() => import('./DeliveryNotesImportTool'));
export const LazySettingsPage = lazy(() => import('../pages/SettingsPage'));

// Loading komponenta
const ComponentLoader = ({ children, fallback = null }) => (
  <Suspense 
    fallback={
      fallback || (
        <div className="flex items-center justify-center p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-2 text-gray-600">Načítání...</span>
        </div>
      )
    }
  >
    {children}
  </Suspense>
);

// Wrapper komponenty pro snadné použití
export const LazyBackupSettings = (props) => (
  <ComponentLoader>
    <LazyBackupSettingsComponent {...props} />
  </ComponentLoader>
);

export const LazyImportTool = (props) => (
  <ComponentLoader>
    <LazyDeliveryNotesImportTool {...props} />
  </ComponentLoader>
);

export const LazySettings = (props) => (
  <ComponentLoader>
    <LazySettingsPage {...props} />
  </ComponentLoader>
);

export default ComponentLoader;