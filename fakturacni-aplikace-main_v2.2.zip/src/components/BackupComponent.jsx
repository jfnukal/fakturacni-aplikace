import React, { useState, useEffect } from 'react';
import { Download, Save, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { useTranslation } from 'react-i18next'; 
import BackupService from '../services/BackupService';
import BackupReminderService from '../services/BackupReminderService';

const BackupComponent = ({ currentUser }) => {
  const { t } = useTranslation();
  const [backupService] = useState(() => new BackupService(currentUser));
  const [reminderService] = useState(
    () => new BackupReminderService(currentUser)
  );
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);
  const [lastError, setLastError] = useState(null);
  const [backupStats, setBackupStats] = useState(null);

  useEffect(() => {
    if (currentUser) {
      setBackupStats(reminderService.getBackupStats());
    }
  }, [currentUser, reminderService]);

  const handleCreateFullBackup = async () => {
    setIsCreatingBackup(true);
    setLastError(null);

    try {
      const backupData = await backupService.createFullBackup();
      const filename = backupService.generateBackupFilename('full');
      
      backupService.downloadBackup(backupData, filename);
      reminderService.recordBackupCreated();
      
      setBackupStats(reminderService.getBackupStats());
      alert(t('backup_system.create_backup.success_full'));
    } catch (error) {
      console.error('Chyba při vytváření zálohy:', error);
      setLastError(error.message);
    } finally {
      setIsCreatingBackup(false);
    }
  };

  const handleCreateDocumentsBackup = async () => {
    setIsCreatingBackup(true);
    setLastError(null);

    try {
      const backupData = await backupService.createDocumentsBackup();
      const filename = backupService.generateBackupFilename('documents');
      
      backupService.downloadBackup(backupData, filename);
      reminderService.recordBackupCreated();
      
      setBackupStats(reminderService.getBackupStats());
      alert(t('backup_system.create_backup.success_documents'));
    } catch (error) {
      console.error('Chyba při vytváření zálohy dokumentů:', error);
      setLastError(error.message);
    } finally {
      setIsCreatingBackup(false);
    }
  };

  const formatDate = (date) => {
    if (!date) return t('backup_system.create_backup.info.never');
    return new Intl.DateTimeFormat('cs-CZ', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  if (!currentUser) {
    return <div>{t('backup_system.common.login_required', { action: 'vytvoření zálohy' })}</div>;
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Save className="w-5 h-5" />
          {t('backup_system.create_backup.title')}
        </h3>

        {/* Statistiky */}
        {backupStats && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-medium mb-3">{t('backup_system.create_backup.info.title')}</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-gray-600">{t('backup_system.create_backup.info.total_backups')}</span>
                <div className="font-semibold">{backupStats.totalBackups}</div>
              </div>
              <div>
                <span className="text-gray-600">{t('backup_system.create_backup.info.last_backup')}</span>
                <div className="font-semibold">{formatDate(backupStats.lastBackupDate)}</div>
              </div>
              <div>
                <span className="text-gray-600">{t('backup_system.create_backup.info.days_since')}</span>
                <div className={`font-semibold ${backupStats.isOverdue ? 'text-red-600' : 'text-green-600'}`}>
                  {backupStats.daysSinceLastBackup || t('backup_system.common.na')}
                </div>
              </div>
            </div>
            
            {backupStats.shouldRemind && (
              <div className="mt-3 p-3 bg-orange-100 border border-orange-300 rounded flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-600" />
                <span className="text-orange-800">{t('backup_system.reminder.title')}</span>
              </div>
            )}
          </div>
        )}

        {/* Tlačítka pro vytvoření záloh */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            onClick={handleCreateFullBackup}
            disabled={isCreatingBackup}
            className="flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            {isCreatingBackup ? (
              <Clock className="w-5 h-5 animate-spin" />
            ) : (
              <Download className="w-5 h-5" />
            )}
            {t('backup_system.create_backup.full_backup')}
          </button>

          <button
            onClick={handleCreateDocumentsBackup}
            disabled={isCreatingBackup}
            className="flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            {isCreatingBackup ? (
              <Clock className="w-5 h-5 animate-spin" />
            ) : (
              <Download className="w-5 h-5" />
            )}
            {t('backup_system.create_backup.documents_backup')}
          </button>
        </div>

        {/* Popis záložních variant */}
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="p-3 bg-blue-50 rounded-lg">
            <h5 className="font-semibold text-blue-900 mb-1">{t('backup_system.create_backup.descriptions.full.title')}</h5>
            <p className="text-blue-800">
              {t('backup_system.create_backup.descriptions.full.description')}
            </p>
          </div>
          <div className="p-3 bg-green-50 rounded-lg">
            <h5 className="font-semibold text-green-900 mb-1">{t('backup_system.create_backup.descriptions.documents.title')}</h5>
            <p className="text-green-800">
              {t('backup_system.create_backup.descriptions.documents.description')}
            </p>
          </div>
        </div>

        {/* Chybová zpráva */}
        {lastError && (
          <div className="mt-4 p-3 bg-red-100 border border-red-300 rounded flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-600" />
            <span className="text-red-800">{t('backup_system.common.error_prefix')} {lastError}</span>
          </div>
        )}

        {/* Informace o souborech */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium mb-2 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-blue-600" />{t('backup_system.create_backup.file_info.title')}
          </h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• {t('backup_system.create_backup.file_info.format')}</li>
            <li>• {t('backup_system.create_backup.file_info.naming')}</li>
            <li>• {t('backup_system.create_backup.file_info.storage')}</li>
            <li>• {t('backup_system.create_backup.file_info.compatibility')}</li>
            <li>• {t('backup_system.create_backup.file_info.recommendation')}</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default BackupComponent;
