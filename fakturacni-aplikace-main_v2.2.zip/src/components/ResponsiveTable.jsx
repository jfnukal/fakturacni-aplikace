import PropTypes from 'prop-types';
import React from 'react';

export const ResponsiveTable = ({ children, className = '' }) => {
  return (
    <div className={`w-full overflow-x-auto ${className}`}>
      <table className="min-w-full">
        {children}
      </table>
    </div>
  );
};

export const MobileCard = ({ children, className = '' }) => {
  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-3 hover:shadow-md transition-shadow ${className}`}>
      {children}
    </div>
  );
};

export const DesktopOnly = ({ children }) => {
  return <div className="hidden md:block">{children}</div>;
};

export const MobileOnly = ({ children }) => {
  return <div className="block md:hidden">{children}</div>;
};

ResponsiveTable.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
};

MobileCard.propTypes = {
  children: PropTypes.node.isRequired,  
  className: PropTypes.string,
};

DesktopOnly.propTypes = {
  children: PropTypes.node.isRequired,
};

MobileOnly.propTypes = {
  children: PropTypes.node.isRequired,
};