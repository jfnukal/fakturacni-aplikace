// BackupReminderComponent.jsx - Komponenta pro upozornění na zálohu
import React, { useState, useEffect, memo } from 'react';
import { AlertTriangle, X, Clock, Download } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import BackupReminderService from '../services/BackupReminderService';

const BackupReminderComponent = memo(({ currentUser, onCreateBackup }) => {
  const { t } = useTranslation();
  const [reminderService] = useState(() => new BackupReminderService(currentUser));
  const [shouldShow, setShouldShow] = useState(false);
  const [reminderMessage, setReminderMessage] = useState('');
  const [stats, setStats] = useState(null);

  useEffect(() => {
    if (!currentUser) {
      setShouldShow(false);
      return;
    }

    const checkReminder = () => {
      const backupStats = reminderService.getBackupStats();
      setStats(backupStats);
      setShouldShow(backupStats.shouldRemind);
      
      // Generování zprávy s překlady
      const lastBackup = reminderService.getLastBackupDate();
      if (!lastBackup) {
        setReminderMessage(t('backup_system.reminder.never_created'));
      } else {
        const daysSince = reminderService.getDaysSince(lastBackup);
        const settings = reminderService.getReminderSettings();
        setReminderMessage(t('backup_system.reminder.days_since', { 
          days: daysSince, 
          interval: settings.intervalDays 
        }));
      }
    };

    checkReminder();
    
    // Kontrola každých 10 sekund pro testování (v produkci by bylo 5 minut)
    const interval = setInterval(checkReminder, 10 * 1000);
    
    return () => clearInterval(interval);
  }, [currentUser, reminderService, t]);

  const handleDismiss = () => {
    setShouldShow(false);
  };

  const handleSnooze = (days) => {
    reminderService.snoozeReminder(days);
    setShouldShow(false);
    
    const dayWord = days === 1 ? t('backup_system.reminder.day_singular') : t('backup_system.reminder.days_plural');
    alert(t('backup_system.reminder.snooze_success', { days, dayWord }));
  };

  const handleCreateBackup = () => {
    if (onCreateBackup) {
      onCreateBackup();
    }
    setShouldShow(false);
  };

  if (!shouldShow || !currentUser) {
    return null;
  }

  return (
    <div className="fixed top-4 right-4 left-4 md:left-auto md:w-96 bg-orange-100 border border-orange-300 rounded-lg shadow-lg p-4 z-50 animate-slide-down">
      <div className="flex items-start gap-3">
        <AlertTriangle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" />
        
        <div className="flex-1 min-w-0">
          <h4 className="font-semibold text-orange-900 mb-1">
            {t('backup_system.reminder.title')}
          </h4>
          <p className="text-sm text-orange-800 mb-3">
            {reminderMessage}
          </p>
          
          {stats && (
            <div className="text-xs text-orange-700 mb-3 space-y-1">
              <div>{t('backup_system.reminder.stats.total_backups', { count: stats.totalBackups })}</div>
              <div>{t('backup_system.reminder.stats.days_since', { days: stats.daysSinceLastBackup || 0 })}</div>
            </div>
          )}
          
          <div className="flex flex-wrap gap-2">
            <button
              onClick={handleCreateBackup}
              className="flex items-center gap-1 px-3 py-1.5 bg-orange-600 text-white rounded text-sm hover:bg-orange-700 transition-colors"
            >
              <Download className="w-3 h-3" />
              {t('backup_system.reminder.actions.create_backup')}
            </button>
            
            <button
              onClick={() => handleSnooze(1)}
              className="px-3 py-1.5 border border-orange-400 text-orange-800 rounded text-sm hover:bg-orange-50 transition-colors"
            >
              {t('backup_system.reminder.actions.snooze_1_day')}
            </button>
            
            <button
              onClick={() => handleSnooze(3)}
              className="px-3 py-1.5 border border-orange-400 text-orange-800 rounded text-sm hover:bg-orange-50 transition-colors"
            >
              {t('backup_system.reminder.actions.snooze_3_days')}
            </button>
          </div>
        </div>
        
        <button
          onClick={handleDismiss}
          className="text-orange-600 hover:text-orange-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
});

export default BackupReminderComponent;