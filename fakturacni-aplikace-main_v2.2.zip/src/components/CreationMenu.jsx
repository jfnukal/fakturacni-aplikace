import React, { useState, useEffect } from 'react';
import { Plus, X, FileText, ListOrdered, Building, Clock } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const CreationMenu = ({ onRequestNew, appSettings }) => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);

  const handleActionClick = (itemType) => {
    onRequestNew(itemType);
    setIsOpen(false);
  };

  // Zavření menu při kliknutí mimo něj
useEffect(() => {
  const handleClickOutside = (event) => {
    const menuElement = event.target.closest('.creation-menu-container');
    const buttonElement = event.target.closest('.creation-menu-button');
    
    if (isOpen && !menuElement && !buttonElement) {
      setIsOpen(false);
    }
  };

  if (isOpen) {
    // Počkáme chvilku, aby se nestalo, že klik na tlačítko menu hned zavře
    setTimeout(() => {
      document.addEventListener('click', handleClickOutside);
    }, 100);
    
    return () => document.removeEventListener('click', handleClickOutside);
  }
}, [isOpen]);

// Zavření menu při stisknutí klávesy Escape
useEffect(() => {
  const handleEscape = (event) => {
    if (event.key === 'Escape' && isOpen) {
      setIsOpen(false);
    }
  };

  if (isOpen) {
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }
}, [isOpen]);

const menuItems = [
  { type: 'invoice', label: t('invoices_page.new'), icon: FileText },
  { type: 'delivery_note', label: t('delivery_notes_page.new'), icon: ListOrdered },
  { type: 'customer', label: t('customers_page.new'), icon: Building },
  ...(appSettings?.attendanceEnabled ? [{ type: 'attendance', label: 'Nový záznam docházky', icon: Clock }] : [])
];

  return (
    <div className="creation-menu-container fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 flex flex-col items-end safe-bottom">
      {/* Menu s položkami, které se zobrazí po kliknutí */}
      <div
        className={`flex flex-col items-end gap-2 sm:gap-3 mb-3 transition-all duration-300 ${
          isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
      >
        {menuItems.map((item) => (
          <button
            key={item.type}
            onClick={() => handleActionClick(item.type)}
            className="flex items-center gap-2 sm:gap-3 bg-white px-3 sm:px-4 py-2 rounded-lg shadow-lg hover:bg-gray-100 transition-colors text-sm sm:text-base"
          >
            <span className="font-medium text-gray-700">{item.label}</span>
            <item.icon size={18} className="text-gray-600 shrink-0" />
          </button>
        ))}
      </div>
  
      {/* Hlavní plovoucí tlačítko */}
      <button
          onClick={() => setIsOpen(!isOpen)}
         className="creation-menu-button relative flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 transition-transform hover:scale-110 focus:outline-none"
         aria-label="Vytvořit nový dokument"
        >
        <Plus
          className={`transition-transform duration-300 ${isOpen ? 'rotate-45 scale-0' : 'rotate-0 scale-100'}`}
          size={28}
        />
        <X
          className={`absolute transition-transform duration-300 ${isOpen ? 'rotate-0 scale-100' : '-rotate-45 scale-0'}`}
          size={28}
        />
      </button>
    </div>
  );
};

export default CreationMenu;