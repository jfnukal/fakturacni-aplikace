// BackupSettingsComponent.jsx - Komponenta pro nastavení připomínek
import React, { useState, useEffect, memo } from 'react';
import { Settings, Bell, BellOff, Clock, Save, RotateCcw } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import BackupReminderService from '../services/BackupReminderService';

const BackupSettingsComponent = memo(({ currentUser }) => {
  const { t } = useTranslation();
  const [reminderService] = useState(
    () => new BackupReminderService(currentUser)
  );
  const [settings, setSettings] = useState({
    enabled: true,
    intervalDays: 7,
    autoBackup: false,
  });
  const [backupStats, setBackupStats] = useState(null);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    if (currentUser) {
      const currentSettings = reminderService.getReminderSettings();
      setSettings(currentSettings);
      setBackupStats(reminderService.getBackupStats());
    }
  }, [currentUser, reminderService]);

  const handleSettingChange = (key, value) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
    setHasChanges(true);
  };

  const handleSaveSettings = () => {
    reminderService.setReminderSettings(settings);
    setBackupStats(reminderService.getBackupStats());
    setHasChanges(false);
    alert('Nastavení připomínek bylo uloženo!');
  };

  const handleResetSettings = () => {
    const defaultSettings = {
      enabled: true,
      intervalDays: 7,
      autoBackup: false,
    };
    setSettings(defaultSettings);
    setHasChanges(true);
  };

  const handleSnoozeReminder = (days) => {
    reminderService.snoozeReminder(days);
    setBackupStats(reminderService.getBackupStats());
    const dayWord = days === 1 ? 'den' : 'dny';
    alert(`Připomínky odloženy na ${days} ${dayWord}.`);
  };

  const handleTestReminder = () => {
    // Simuluje starou zálohu pro aktivaci připomínky
    const testHistory = [
      {
        timestamp: new Date(
          Date.now() - (settings.intervalDays + 1) * 24 * 60 * 60 * 1000
        ).toISOString(),
        type: 'manual',
      },
    ];

    // Dočasně uloží falešnou historii
    const originalHistory = localStorage.getItem(
      `${reminderService.storageKey}_history`
    );
    localStorage.setItem(
      `${reminderService.storageKey}_history`,
      JSON.stringify(testHistory)
    );

    // Odstraní případné odložení
    localStorage.removeItem(`${reminderService.storageKey}_snoozed`);

    // Aktualizuje statistiky
    setBackupStats(reminderService.getBackupStats());

    alert('Test připomínky aktivován! Připomínka by se měla zobrazit za chvíli.');

    // Obnoví původní historii po 5 sekundách
    setTimeout(() => {
      if (originalHistory) {
        localStorage.setItem(
          `${reminderService.storageKey}_history`,
          originalHistory
        );
      } else {
        localStorage.removeItem(`${reminderService.storageKey}_history`);
      }
      setBackupStats(reminderService.getBackupStats());
    }, 5000);
  };

  return (
    <div className="space-y-6">
      {/* Aktuální stav */}
      {backupStats && (
        <div className="bg-white rounded-lg border p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Settings className="w-5 h-5" />
            {t('backup_system.backup_settings.current_status.title')}
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-gray-600">{t('backup_system.backup_settings.current_status.total_backups')}</span>
              <div className="font-semibold">{backupStats.totalBackups}</div>
            </div>
            <div>
              <span className="text-gray-600">{t('backup_system.backup_settings.current_status.last_backup')}</span>
              <div className="font-semibold">
                {backupStats.lastBackupDate 
                  ? new Date(backupStats.lastBackupDate).toLocaleDateString('cs-CZ')
                  : 'Nikdy'
                }
              </div>
            </div>
            <div>
              <span className="text-gray-600">{t('backup_system.backup_settings.current_status.days_since')}</span>
              <div className="font-semibold">{backupStats.daysSinceLastBackup || 0}</div>
            </div>
            <div>
              <span className="text-gray-600">{t('backup_system.backup_settings.current_status.status')}</span>
              <div className={`font-semibold ${backupStats.shouldRemind ? 'text-orange-600' : 'text-green-600'}`}>
                {backupStats.shouldRemind 
                  ? t('backup_system.backup_settings.current_status.remind')
                  : t('backup_system.backup_settings.current_status.ok')
                }
              </div>
            </div>
          </div>

          {/* Odložit připomínky */}
          {backupStats.shouldRemind && (
            <div className="mt-4 p-3 bg-orange-50 rounded-lg">
              <h5 className="font-medium text-orange-900 mb-2">
                {t('backup_system.backup_settings.snooze.title')}
              </h5>
              <div className="flex gap-2">
                <button
                  onClick={() => handleSnoozeReminder(1)}
                  className="px-3 py-1 bg-orange-600 text-white rounded text-sm hover:bg-orange-700 transition-colors"
                >
                  {t('backup_system.backup_settings.snooze.1_day')}
                </button>
                <button
                  onClick={() => handleSnoozeReminder(3)}
                  className="px-3 py-1 bg-orange-600 text-white rounded text-sm hover:bg-orange-700 transition-colors"
                >
                  {t('backup_system.backup_settings.snooze.3_days')}
                </button>
                <button
                  onClick={() => handleSnoozeReminder(7)}
                  className="px-3 py-1 bg-orange-600 text-white rounded text-sm hover:bg-orange-700 transition-colors"
                >
                  {t('backup_system.backup_settings.snooze.1_week')}
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Nastavení připomínek */}
      <div className="bg-white rounded-lg border p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Bell className="w-5 h-5" />
          {t('backup_system.backup_settings.title')}
        </h3>

        <div className="space-y-6">
          {/* Povolit připomínky */}
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">{t('backup_system.backup_settings.enable_reminders.title')}</div>
              <div className="text-sm text-gray-600">{t('backup_system.backup_settings.enable_reminders.description')}</div>
            </div>
            <button
              onClick={() => handleSettingChange('enabled', !settings.enabled)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.enabled ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.enabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Frekvence připomínek */}
          <div>
            <div className="font-medium mb-2">{t('backup_system.backup_settings.frequency.title')}</div>
            <div className="text-sm text-gray-600 mb-3">{t('backup_system.backup_settings.frequency.description')}</div>
            <select
              value={settings.intervalDays}
              onChange={(e) => handleSettingChange('intervalDays', parseInt(e.target.value))}
              disabled={!settings.enabled}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm disabled:bg-gray-100 disabled:text-gray-500"
            >
              <option value={1}>{t('backup_system.backup_settings.frequency.1_day')}</option>
              <option value={3}>{t('backup_system.backup_settings.frequency.3_days')}</option>
              <option value={7}>{t('backup_system.backup_settings.frequency.1_week')}</option>
              <option value={14}>{t('backup_system.backup_settings.frequency.2_weeks')}</option>
              <option value={30}>{t('backup_system.backup_settings.frequency.1_month')}</option>
            </select>
          </div>

          {/* Automatické zálohování - budoucí funkce */}
          <div className="flex items-center justify-between opacity-50">
            <div>
              <div className="font-medium">{t('backup_system.backup_settings.auto_backup.title')}</div>
              <div className="text-sm text-gray-600">{t('backup_system.backup_settings.auto_backup.description')}</div>
            </div>
            <button
              disabled
              className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200 cursor-not-allowed"
            >
              <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-1" />
            </button>
          </div>
        </div>

        {/* Tlačítka akcí */}
        <div className="flex flex-wrap gap-3 mt-6">
          <button
            onClick={handleSaveSettings}
            disabled={!hasChanges}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            <Save className="w-4 h-4" />
            {t('backup_system.backup_settings.actions.save')}
          </button>

          <button
            onClick={handleResetSettings}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            {t('backup_system.backup_settings.actions.reset')}
          </button>

          <button
            onClick={handleTestReminder}
            className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
          >
            <Bell className="w-4 h-4" />
            {t('backup_system.backup_settings.actions.test_reminder')}
          </button>
        </div>

        {/* Nápověda */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium mb-2 text-blue-900">
            {t('backup_system.backup_settings.tips.title')}
          </h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• {t('backup_system.backup_settings.tips.weekly')}</li>
            <li>• {t('backup_system.backup_settings.tips.multiple_locations')}</li>
            <li>• {t('backup_system.backup_settings.tips.test_restore')}</li>
            <li>• {t('backup_system.backup_settings.tips.before_changes')}</li>
            <li>• {t('backup_system.backup_settings.tips.snooze_option')}</li>
          </ul>
        </div>
      </div>
    </div>
  );
});

export default BackupSettingsComponent;