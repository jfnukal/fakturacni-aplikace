import React, { useState } from 'react';
import { Upload, FileText, AlertTriangle, CheckCircle, X, RefreshCw } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import BackupService from '../services/BackupService';
import RestoreService from '../services/RestoreService';

const RestoreComponent = ({ currentUser }) => {
  const { t } = useTranslation();
  const [backupService] = useState(() => new BackupService(currentUser));
  const [restoreService] = useState(() => new RestoreService(currentUser));
  const [selectedFile, setSelectedFile] = useState(null);
  const [backupPreview, setBackupPreview] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [restoreResults, setRestoreResults] = useState(null);
  const [validationError, setValidationError] = useState(null);
  const [restoreMode, setRestoreMode] = useState('add'); // 'add' nebo 'overwrite'

  const handleFileSelect = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setSelectedFile(file);
    setBackupPreview(null);
    setValidationError(null);
    setRestoreResults(null);

    try {
      const backupData = await restoreService.loadBackupFromFile(file);
      
      // Validace zálohy
      const validation = backupService.validateBackupFile(backupData);
      if (!validation.isValid) {
        setValidationError(validation.errors.join(', '));
        return;
      }

      // Vytvoření náhledu
      const preview = restoreService.generateBackupPreview(backupData);
      setBackupPreview({ ...preview, rawData: backupData });
    } catch (error) {
      setValidationError(error.message);
    }
  };

  const handleRestore = async () => {
    if (!backupPreview?.rawData) return;

    setIsProcessing(true);
    setRestoreResults(null);

    try {
      const options = { overwrite: restoreMode === 'overwrite' };
      let results;

      if (backupPreview.rawData.metadata?.type === 'documents_only') {
        results = await restoreService.restoreDocumentsBackup(backupPreview.rawData, options);
      } else {
        results = await restoreService.restoreFullBackup(backupPreview.rawData, options);
      }

      setRestoreResults(results);
    } catch (error) {
      setRestoreResults({
        errors: [t('backup_system.common.error_prefix') + ' ' + error.message]
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const resetComponent = () => {
    setSelectedFile(null);
    setBackupPreview(null);
    setValidationError(null);
    setRestoreResults(null);
    setRestoreMode('add');
  };

  const formatDate = (dateString) => {
    if (!dateString) return t('backup_system.common.na');
    return new Intl.DateTimeFormat('cs-CZ', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(dateString));
  };

  if (!currentUser) {
    return <div>{t('backup_system.common.login_required', { action: 'obnovení ze zálohy' })}</div>;
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <RefreshCw className="w-5 h-5" />
          {t('backup_system.restore_backup.title')}
        </h3>

        {/* Varování */}
        <div className="mb-6 p-4 bg-yellow-50 border border-yellow-300 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-5 h-5 text-yellow-600" />
            <span className="font-semibold text-yellow-800">{t('backup_system.restore_backup.warning.title')}</span>
          </div>
          <p className="text-yellow-800 text-sm">
            {t('backup_system.restore_backup.warning.message')}
          </p>
        </div>

        {!selectedFile && (
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h4 className="text-lg font-medium text-gray-900 mb-2">
              {t('backup_system.restore_backup.file_select.title')}
            </h4>
            <p className="text-gray-600 mb-4">
              {t('backup_system.restore_backup.file_select.description')}
            </p>
            <input
              type="file"
              accept=".json"
              onChange={handleFileSelect}
              className="hidden"
              id="backup-file"
            />
            <label
              htmlFor="backup-file"
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer transition-colors"
            >
              <FileText className="w-4 h-4" />
              {t('backup_system.restore_backup.file_select.button')}
            </label>
          </div>
        )}

        {/* Chyba validace */}
        {validationError && (
          <div className="p-4 bg-red-100 border border-red-300 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <X className="w-5 h-5 text-red-600" />
              <span className="font-semibold text-red-800">{t('backup_system.restore_backup.validation.invalid_title')}</span>
            </div>
            <p className="text-red-800 text-sm">{validationError}</p>
            <button
              onClick={resetComponent}
              className="mt-2 px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700 transition-colors"
            >
              {t('backup_system.restore_backup.validation.select_other')}
            </button>
          </div>
        )}

        {/* Náhled zálohy */}
        {backupPreview && !validationError && (
          <div className="space-y-4">
            <div className="bg-green-50 border border-green-300 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="font-semibold text-green-800">{t('backup_system.restore_backup.preview.valid_title')}</span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">{t('backup_system.restore_backup.preview.created')}</span>
                  <div className="font-semibold">{formatDate(backupPreview.metadata?.createdAt)}</div>
                </div>
                <div>
                  <span className="text-gray-600">{t('backup_system.restore_backup.preview.version')}</span>
                  <div className="font-semibold">{backupPreview.metadata?.version || t('backup_system.common.na')}</div>
                </div>
              </div>

              <div className="mt-4">
                <span className="text-gray-600 text-sm">{t('backup_system.restore_backup.preview.content')}</span>
                <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                  {backupPreview.hasSettings && (
                    <div className="bg-white px-2 py-1 rounded border">
                      {t('backup_system.restore_backup.preview.settings')}
                    </div>
                  )}
                  {backupPreview.customersCount > 0 && (
                    <div className="bg-white px-2 py-1 rounded border">
                      {t('backup_system.restore_backup.preview.customers')} ({backupPreview.customersCount})
                    </div>
                  )}
                  {backupPreview.productsCount > 0 && (
                    <div className="bg-white px-2 py-1 rounded border">
                      {t('backup_system.restore_backup.preview.products')} ({backupPreview.productsCount})
                    </div>
                  )}
                  {backupPreview.deliveryNotesCount > 0 && (
                    <div className="bg-white px-2 py-1 rounded border">
                      {t('backup_system.restore_backup.preview.delivery_notes')} ({backupPreview.deliveryNotesCount})
                    </div>
                  )}
                  {backupPreview.invoicesCount > 0 && (
                    <div className="bg-white px-2 py-1 rounded border">
                      {t('backup_system.restore_backup.preview.invoices')} ({backupPreview.invoicesCount})
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Volba režimu obnovení */}
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium mb-3">{t('backup_system.restore_backup.restore_mode.title')}</h4>
              <div className="space-y-2">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="restoreMode"
                    value="add"
                    checked={restoreMode === 'add'}
                    onChange={(e) => setRestoreMode(e.target.value)}
                    className="text-blue-600"
                  />
                  <div>
                    <div className="font-medium text-sm">{t('backup_system.restore_backup.restore_mode.add.title')}</div>
                    <div className="text-xs text-gray-600">{t('backup_system.restore_backup.restore_mode.add.description')}</div>
                  </div>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="restoreMode"
                    value="overwrite"
                    checked={restoreMode === 'overwrite'}
                    onChange={(e) => setRestoreMode(e.target.value)}
                    className="text-red-600"
                  />
                  <div>
                    <div className="font-medium text-sm text-red-800">{t('backup_system.restore_backup.restore_mode.overwrite.title')}</div>
                    <div className="text-xs text-red-600">{t('backup_system.restore_backup.restore_mode.overwrite.description')}</div>
                  </div>
                </label>
              </div>
            </div>

            {/* Tlačítka */}
            <div className="flex gap-3">
              <button
                onClick={handleRestore}
                disabled={isProcessing}
                className={`flex items-center gap-2 px-4 py-2 text-white rounded-lg transition-colors ${
                  restoreMode === 'overwrite' 
                    ? 'bg-red-600 hover:bg-red-700 disabled:bg-gray-400'
                    : 'bg-green-600 hover:bg-green-700 disabled:bg-gray-400'
                } disabled:cursor-not-allowed`}
              >
                {isProcessing ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4" />
                )}
                {isProcessing ? t('backup_system.restore_backup.actions.restoring') : t('backup_system.restore_backup.actions.restore')}
              </button>
              
              <button
                onClick={resetComponent}
                disabled={isProcessing}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 disabled:cursor-not-allowed transition-colors"
              >
                {t('backup_system.restore_backup.actions.cancel')}
              </button>
            </div>
          </div>
        )}

        {/* Výsledky obnovení */}
        {restoreResults && (
          <div className="mt-6 p-4 border rounded-lg">
            <h4 className="font-semibold mb-3">{t('backup_system.restore_backup.results.title')}</h4>
            
            {restoreResults.errors?.length > 0 ? (
              <div className="space-y-2">
                <div className="text-red-600 font-medium">{t('backup_system.restore_backup.results.errors')}</div>
                {restoreResults.errors.map((error, index) => (
                  <div key={index} className="text-sm text-red-800 bg-red-100 p-2 rounded">
                    {error}
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-green-600 font-medium">
                  <CheckCircle className="w-5 h-5" />
                  {t('backup_system.restore_backup.results.success')}
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                  {restoreResults.settings && (
                    <div className="bg-green-100 px-2 py-1 rounded">
                      {t('backup_system.restore_backup.preview.settings')}
                    </div>
                  )}
                  {restoreResults.customers > 0 && (
                    <div className="bg-green-100 px-2 py-1 rounded">
                      {t('backup_system.restore_backup.preview.customers')} ({restoreResults.customers})
                    </div>
                  )}
                  {restoreResults.products > 0 && (
                    <div className="bg-green-100 px-2 py-1 rounded">
                      {t('backup_system.restore_backup.preview.products')} ({restoreResults.products})
                    </div>
                  )}
                  {restoreResults.deliveryNotes > 0 && (
                    <div className="bg-green-100 px-2 py-1 rounded">
                      {t('backup_system.restore_backup.preview.delivery_notes')} ({restoreResults.deliveryNotes})
                    </div>
                  )}
                  {restoreResults.invoices > 0 && (
                    <div className="bg-green-100 px-2 py-1 rounded">
                      {t('backup_system.restore_backup.preview.invoices')} ({restoreResults.invoices})
                    </div>
                  )}
                </div>
              </div>
            )}

            <button
              onClick={resetComponent}
              className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              {t('backup_system.restore_backup.results.restore_another')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default RestoreComponent;