// BackupService.jsx - Služba pro správu záloh
import { db } from '../firebase';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';

export class BackupService {
  constructor(currentUser) {
    this.currentUser = currentUser;
  }

  // Vytvoření kompletní zálohy všech dat
  async createFullBackup() {
    if (!this.currentUser) {
      throw new Error('Uživatel není přihlášen');
    }

    const backupData = {
      metadata: {
        version: '1.0.0',
        createdAt: new Date().toISOString(),
        userId: this.currentUser.uid,
        userEmail: this.currentUser.email,
        appVersion: '1.0.0'
      },
      settings: null,
      customers: [],
      products: [],
      deliveryNotes: [],
      invoices: []
    };

    try {
      // Načtení nastavení
      const settingsDoc = await getDoc(doc(db, 'settings', this.currentUser.uid));
      if (settingsDoc.exists()) {
        backupData.settings = settingsDoc.data();
      }

      // Načtení zákazníků
      const customersQuery = query(
        collection(db, 'customers'),
        where('userId', '==', this.currentUser.uid)
      );
      const customersSnapshot = await getDocs(customersQuery);
      backupData.customers = customersSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      // Načtení produktů
      const productsQuery = query(
        collection(db, 'products'),
        where('userId', '==', this.currentUser.uid)
      );
      const productsSnapshot = await getDocs(productsQuery);
      backupData.products = productsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      // Načtení dodacích listů
      const deliveryNotesQuery = query(
        collection(db, 'deliveryNotes'),
        where('userId', '==', this.currentUser.uid)
      );
      const deliveryNotesSnapshot = await getDocs(deliveryNotesQuery);
      backupData.deliveryNotes = deliveryNotesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      // Načtení faktur
      const invoicesQuery = query(
        collection(db, 'invoices'),
        where('userId', '==', this.currentUser.uid)
      );
      const invoicesSnapshot = await getDocs(invoicesQuery);
      backupData.invoices = invoicesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      return backupData;
    } catch (error) {
      console.error('Chyba při vytváření zálohy:', error);
      throw error;
    }
  }

  // Vytvoření částečné zálohy (pouze faktury a dodací listy)
  async createDocumentsBackup() {
    if (!this.currentUser) {
      throw new Error('Uživatel není přihlášen');
    }

    const backupData = {
      metadata: {
        version: '1.0.0',
        type: 'documents_only',
        createdAt: new Date().toISOString(),
        userId: this.currentUser.uid,
        userEmail: this.currentUser.email,
      },
      deliveryNotes: [],
      invoices: []
    };

    try {
      // Načtení dodacích listů
      const deliveryNotesQuery = query(
        collection(db, 'deliveryNotes'),
        where('userId', '==', this.currentUser.uid)
      );
      const deliveryNotesSnapshot = await getDocs(deliveryNotesQuery);
      backupData.deliveryNotes = deliveryNotesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      // Načtení faktur
      const invoicesQuery = query(
        collection(db, 'invoices'),
        where('userId', '==', this.currentUser.uid)
      );
      const invoicesSnapshot = await getDocs(invoicesQuery);
      backupData.invoices = invoicesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      return backupData;
    } catch (error) {
      console.error('Chyba při vytváření zálohy dokumentů:', error);
      throw error;
    }
  }

  // Stažení zálohy jako JSON souboru
  downloadBackup(backupData, filename) {
    const dataStr = JSON.stringify(backupData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  // Generování názvu souboru zálohy
  generateBackupFilename(type = 'full') {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0]; // YYYY-MM-DD
    const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, ''); // HHMMSS
    
    const prefix = type === 'full' ? 'ucetnictvi_zaloha_kompletni' : 'ucetnictvi_zaloha_dokumenty';
    return `${prefix}_${dateStr}_${timeStr}.json`;
  }

  // Validace záložního souboru
  validateBackupFile(backupData) {
    const errors = [];

    if (!backupData.metadata) {
      errors.push('Chybí metadata zálohy');
    }

    if (!backupData.metadata?.version) {
      errors.push('Chybí verze zálohy');
    }

    if (!backupData.metadata?.userId) {
      errors.push('Chybí ID uživatele v záloze');
    }

    if (!Array.isArray(backupData.deliveryNotes)) {
      errors.push('Neplatný formát dodacích listů');
    }

    if (!Array.isArray(backupData.invoices)) {
      errors.push('Neplatný formát faktur');
    }

    // Kontrola kompatibility s aktuálním uživatelem
    if (backupData.metadata?.userId !== this.currentUser?.uid) {
      errors.push('Záloha patří jinému uživateli');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}

export default BackupService;