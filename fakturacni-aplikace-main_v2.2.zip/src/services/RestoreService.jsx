// RestoreService.jsx - Služba pro obnovení ze zálohy
import { db } from '../firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  addDoc, 
  writeBatch,
  query,
  where,
  getDocs,
  deleteDoc
} from 'firebase/firestore';

export class RestoreService {
  constructor(currentUser) {
    this.currentUser = currentUser;
  }

  // Kompletní obnovení dat ze zálohy (POZOR: Přepíše všechna existující data!)
  async restoreFullBackup(backupData, options = { overwrite: false }) {
    if (!this.currentUser) {
      throw new Error('Uživatel není přihlášen');
    }

    const results = {
      settings: false,
      customers: 0,
      products: 0,
      deliveryNotes: 0,
      invoices: 0,
      errors: []
    };

    try {
      const batch = writeBatch(db);

      // Obnovení nastavení
      if (backupData.settings) {
        try {
          await setDoc(doc(db, 'settings', this.currentUser.uid), {
            ...backupData.settings,
            userId: this.currentUser.uid
          });
          results.settings = true;
        } catch (error) {
          results.errors.push(`Chyba při obnovení nastavení: ${error.message}`);
        }
      }

      // Volitelně smazat existující data před obnovením
      if (options.overwrite) {
        await this.clearAllUserData();
      }

      // Obnovení zákazníků
      if (backupData.customers?.length > 0) {
        for (const customer of backupData.customers) {
          try {
            const customerData = { ...customer };
            delete customerData.id; // Odstraní původní ID
            customerData.userId = this.currentUser.uid; // Ujistí se, že patří aktuálnímu uživateli
            
            await addDoc(collection(db, 'customers'), customerData);
            results.customers++;
          } catch (error) {
            results.errors.push(`Chyba při obnovení zákazníka "${customer.name}": ${error.message}`);
          }
        }
      }

      // Obnovení produktů
      if (backupData.products?.length > 0) {
        for (const product of backupData.products) {
          try {
            const productData = { ...product };
            delete productData.id;
            productData.userId = this.currentUser.uid;
            
            await addDoc(collection(db, 'products'), productData);
            results.products++;
          } catch (error) {
            results.errors.push(`Chyba při obnovení produktu "${product.name}": ${error.message}`);
          }
        }
      }

      // Obnovení dodacích listů
      if (backupData.deliveryNotes?.length > 0) {
        for (const deliveryNote of backupData.deliveryNotes) {
          try {
            const dlData = { ...deliveryNote };
            delete dlData.id;
            dlData.userId = this.currentUser.uid;
            
            await addDoc(collection(db, 'deliveryNotes'), dlData);
            results.deliveryNotes++;
          } catch (error) {
            results.errors.push(`Chyba při obnovení dodacího listu "${deliveryNote.number}": ${error.message}`);
          }
        }
      }

      // Obnovení faktur
      if (backupData.invoices?.length > 0) {
        for (const invoice of backupData.invoices) {
          try {
            const invoiceData = { ...invoice };
            delete invoiceData.id;
            invoiceData.userId = this.currentUser.uid;
            
            await addDoc(collection(db, 'invoices'), invoiceData);
            results.invoices++;
          } catch (error) {
            results.errors.push(`Chyba při obnovení faktury "${invoice.number}": ${error.message}`);
          }
        }
      }

      return results;
    } catch (error) {
      console.error('Chyba při obnovování zálohy:', error);
      results.errors.push(`Obecná chyba: ${error.message}`);
      return results;
    }
  }

  // Obnovení pouze dokumentů (faktury a dodací listy)
  async restoreDocumentsBackup(backupData, options = { overwrite: false }) {
    if (!this.currentUser) {
      throw new Error('Uživatel není přihlášen');
    }

    const results = {
      deliveryNotes: 0,
      invoices: 0,
      errors: []
    };

    try {
      // Volitelně smazat existující dokumenty
      if (options.overwrite) {
        await this.clearDocuments();
      }

      // Obnovení dodacích listů
      if (backupData.deliveryNotes?.length > 0) {
        for (const deliveryNote of backupData.deliveryNotes) {
          try {
            const dlData = { ...deliveryNote };
            delete dlData.id;
            dlData.userId = this.currentUser.uid;
            
            await addDoc(collection(db, 'deliveryNotes'), dlData);
            results.deliveryNotes++;
          } catch (error) {
            results.errors.push(`Chyba při obnovení dodacího listu "${deliveryNote.number}": ${error.message}`);
          }
        }
      }

      // Obnovení faktur
      if (backupData.invoices?.length > 0) {
        for (const invoice of backupData.invoices) {
          try {
            const invoiceData = { ...invoice };
            delete invoiceData.id;
            invoiceData.userId = this.currentUser.uid;
            
            await addDoc(collection(db, 'invoices'), invoiceData);
            results.invoices++;
          } catch (error) {
            results.errors.push(`Chyba při obnovení faktury "${invoice.number}": ${error.message}`);
          }
        }
      }

      return results;
    } catch (error) {
      console.error('Chyba při obnovování dokumentů:', error);
      results.errors.push(`Obecná chyba: ${error.message}`);
      return results;
    }
  }

  // Smazání všech dat uživatele (POZOR: Nevratná operace!)
  async clearAllUserData() {
    const collections = ['customers', 'products', 'deliveryNotes', 'invoices'];
    
    for (const collectionName of collections) {
      const q = query(
        collection(db, collectionName),
        where('userId', '==', this.currentUser.uid)
      );
      
      const snapshot = await getDocs(q);
      const batch = writeBatch(db);
      
      snapshot.docs.forEach(docSnapshot => {
        batch.delete(docSnapshot.ref);
      });
      
      await batch.commit();
    }
  }

  // Smazání pouze dokumentů uživatele
  async clearDocuments() {
    const collections = ['deliveryNotes', 'invoices'];
    
    for (const collectionName of collections) {
      const q = query(
        collection(db, collectionName),
        where('userId', '==', this.currentUser.uid)
      );
      
      const snapshot = await getDocs(q);
      const batch = writeBatch(db);
      
      snapshot.docs.forEach(docSnapshot => {
        batch.delete(docSnapshot.ref);
      });
      
      await batch.commit();
    }
  }

  // Načtení a parsování zálohy ze souboru
  async loadBackupFromFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const backupData = JSON.parse(e.target.result);
          resolve(backupData);
        } catch (error) {
          reject(new Error('Neplatný formát záložního souboru'));
        }
      };
      
      reader.onerror = () => {
        reject(new Error('Chyba při čtení souboru'));
      };
      
      reader.readAsText(file);
    });
  }

  // Preview zálohy (co obsahuje)
  generateBackupPreview(backupData) {
    return {
      metadata: backupData.metadata,
      hasSettings: !!backupData.settings,
      customersCount: backupData.customers?.length || 0,
      productsCount: backupData.products?.length || 0,
      deliveryNotesCount: backupData.deliveryNotes?.length || 0,
      invoicesCount: backupData.invoices?.length || 0,
      totalDocuments: (backupData.deliveryNotes?.length || 0) + (backupData.invoices?.length || 0)
    };
  }
}

export default RestoreService;