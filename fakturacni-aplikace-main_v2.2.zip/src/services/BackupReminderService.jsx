export class BackupReminderService {
  constructor(currentUser) {
    this.currentUser = currentUser;
    this.storageKey = `backup_reminder_${currentUser?.uid}`;
  }

  // Nastavení připomínání
  setReminderSettings(settings) {
    const reminderData = {
      enabled: settings.enabled,
      intervalDays: settings.intervalDays,
      autoBackup: settings.autoBackup,
      lastUpdated: new Date().toISOString()
    };
    
    localStorage.setItem(this.storageKey, JSON.stringify(reminderData));
  }

  // Získání nastavení připomínání
  getReminderSettings() {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (error) {
      console.error('Chyba při načítání nastavení připomínání:', error);
    }
    
    // Výchozí nastavení
    return {
      enabled: true,
      intervalDays: 7,
      autoBackup: false,
      lastUpdated: null
    };
  }

  // Zaznamenání provedení zálohy
  recordBackupCreated() {
    const backupHistory = this.getBackupHistory();
    backupHistory.push({
      timestamp: new Date().toISOString(),
      type: 'manual'
    });
    
    // Ponechat jen posledních 10 záznamů
    if (backupHistory.length > 10) {
      backupHistory.splice(0, backupHistory.length - 10);
    }
    
    localStorage.setItem(`${this.storageKey}_history`, JSON.stringify(backupHistory));
  }

  // Získání historie záloh
  getBackupHistory() {
    try {
      const stored = localStorage.getItem(`${this.storageKey}_history`);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Chyba při načítání historie záloh:', error);
      return [];
    }
  }

  // Kontrola, zda je třeba připomenout zálohu
  shouldShowReminder() {
    const settings = this.getReminderSettings();
    
    if (!settings.enabled) {
      return false;
    }

    const lastBackup = this.getLastBackupDate();
    if (!lastBackup) {
      return true; // Nikdy nebyła záloha
    }

    const daysSinceLastBackup = this.getDaysSince(lastBackup);
    return daysSinceLastBackup >= settings.intervalDays;
  }

  // Získání data poslední zálohy
  getLastBackupDate() {
    const history = this.getBackupHistory();
    if (history.length === 0) {
      return null;
    }
    
    return new Date(history[history.length - 1].timestamp);
  }

  // Výpočet počtu dní od data
  getDaysSince(date) {
    const now = new Date();
    const diffTime = Math.abs(now - date);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  // Získání textu pro připomínku
  getReminderMessage() {
    const lastBackup = this.getLastBackupDate();
    
    if (!lastBackup) {
      return 'Ještě jste nevytvořili žádnou zálohu. Doporučujeme vytvořit zálohu vašich dat.';
    }
    
    const daysSince = this.getDaysSince(lastBackup);
    const settings = this.getReminderSettings();
    
    return `Poslední záloha byla vytvořena před ${daysSince} dny. Doporučená frekvence je každých ${settings.intervalDays} dní.`;
  }

  // Označení připomínky jako "odložené"
  snoozeReminder(days = 1) {
    const snoozeUntil = new Date();
    snoozeUntil.setDate(snoozeUntil.getDate() + days);
    
    localStorage.setItem(`${this.storageKey}_snoozed`, snoozeUntil.toISOString());
  }

  // Kontrola, zda je připomínka odložená
  isReminderSnoozed() {
    try {
      const snoozeUntil = localStorage.getItem(`${this.storageKey}_snoozed`);
      if (!snoozeUntil) {
        return false;
      }
      
      const snoozeDate = new Date(snoozeUntil);
      const now = new Date();
      
      if (now < snoozeDate) {
        return true;
      } else {
        // Smazat prošlé odložení
        localStorage.removeItem(`${this.storageKey}_snoozed`);
        return false;
      }
    } catch (error) {
      console.error('Chyba při kontrole odložení:', error);
      return false;
    }
  }

  // Získání statistik zálohování
  getBackupStats() {
    const history = this.getBackupHistory();
    const settings = this.getReminderSettings();
    const lastBackup = this.getLastBackupDate();
    
    return {
      totalBackups: history.length,
      lastBackupDate: lastBackup,
      daysSinceLastBackup: lastBackup ? this.getDaysSince(lastBackup) : null,
      reminderEnabled: settings.enabled,
      intervalDays: settings.intervalDays,
      shouldRemind: this.shouldShowReminder() && !this.isReminderSnoozed(),
      isOverdue: lastBackup ? this.getDaysSince(lastBackup) > settings.intervalDays : true
    };
  }

  // Automatická záloha (pokud je povolena)
  shouldTriggerAutoBackup() {
    const settings = this.getReminderSettings();
    
    if (!settings.autoBackup || !settings.enabled) {
      return false;
    }

    return this.shouldShowReminder();
  }

  // Export/import nastavení
  exportSettings() {
    const settings = this.getReminderSettings();
    const history = this.getBackupHistory();
    
    return {
      settings,
      history,
      exportedAt: new Date().toISOString()
    };
  }

  importSettings(data) {
    if (data.settings) {
      this.setReminderSettings(data.settings);
    }
    
    if (data.history) {
      localStorage.setItem(`${this.storageKey}_history`, JSON.stringify(data.history));
    }
  }
}

export default BackupReminderService;