/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      screens: {
        'xs': '475px',
        // Tailwind už má sm: 640px, md: 768px, lg: 1024px, xl: 1280px, 2xl: 1536px
      },
      spacing: {
        'safe': 'env(safe-area-inset-bottom)',
      },
      maxWidth: {
        'modal': '90vw',
        'modal-lg': '1024px',
      }
    },
  },
  plugins: [],
}